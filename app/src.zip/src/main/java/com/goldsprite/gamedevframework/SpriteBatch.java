package com.goldsprite.gamedevframework;

public class SpriteBatch
{
	public void drawTex(Texture tex, float x, float y, float width, float height){
		
	}
}
