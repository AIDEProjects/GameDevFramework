package com.goldsprite.gamedevframework;
import android.opengl.*;
import java.nio.*;

public class Texture {
	private FloatBuffer vertexBuffer;
	private FloatBuffer texCoordBuffer;
	private int textureId;
	private int program;

	// 纹理的宽和高
	public float textureWidth;
	public float textureHeight;
	public float aspectRatio;

	public Texture(int[] texData) {
		init(texData);
	}

	private void init(int[] texData) {
		// 加载纹理
		textureId = texData[0];
		textureWidth = texData[1];
		textureHeight = texData[2];

		// 顶点坐标，确保它们的比例与纹理一致
		aspectRatio = textureWidth / textureHeight; 
		float width = 1 * aspectRatio;
		float height = 1;
		float halfWidth = width/2f; 
		float halfHeight = height/2f;

		float[] vertices = {
			-halfWidth, -halfHeight, // Bottom Left
			halfWidth, -halfHeight, // Bottom Right
			-halfWidth,  halfHeight, // Top Left

			-halfWidth,  halfHeight, // Top Left
			halfWidth, -halfHeight, // Bottom Right
			halfWidth,  halfHeight, // Top Right
		};

		// 纹理坐标
		float[] texCoords = {
			0.0f, 1.0f, // Bottom Left
			1.0f, 1.0f,  // Bottom Right
			0.0f, 0.0f, // Top Left

			0.0f, 0.0f, // Top Left
			1.0f, 1.0f,  // Bottom Right
			1.0f, 0.0f, // Top Right
		};

		// 创建顶点缓冲区
		ByteBuffer bbVertex = ByteBuffer.allocateDirect(vertices.length * 4);
		bbVertex.order(ByteOrder.nativeOrder());
		vertexBuffer = bbVertex.asFloatBuffer();
		vertexBuffer.put(vertices);
		vertexBuffer.position(0);

		// 创建纹理坐标缓冲区
		ByteBuffer bbTexCoord = ByteBuffer.allocateDirect(texCoords.length * 4);
		bbTexCoord.order(ByteOrder.nativeOrder());
		texCoordBuffer = bbTexCoord.asFloatBuffer();
		texCoordBuffer.put(texCoords);
		texCoordBuffer.position(0);

		// 初始化着色器程序
		program = ShaderUtils.getProgram(ShaderUtils.ShaderMode.Texture);
	}

	public void draw(float[] vpMatrix, float cx, float cy, float width, float height) {
		// 使用程序
		GLES20.glUseProgram(program);
		
		int positionHandle = GLES20.glGetAttribLocation(program, "a_Position");
		int matrixHandle = GLES20.glGetUniformLocation(program, "u_Matrix");
		int texCoordHandle = GLES20.glGetAttribLocation(program, "aTexCoord");
		int textueHandle = GLES20.glGetUniformLocation(program, "uTexture");

		// 设置顶点数据
		GLES20.glEnableVertexAttribArray(positionHandle);
		GLES20.glVertexAttribPointer(positionHandle, 2, GLES20.GL_FLOAT, false, 0, vertexBuffer);
		
		//应用矩阵
		float scaleX = width / aspectRatio;
		float scaleY = height;
		float[] modelMatrix = new float[16];
		Matrix.setIdentityM(modelMatrix, 0);
		Matrix.translateM(modelMatrix, 0, cx, cy, 0);
		Matrix.scaleM(modelMatrix, 0, scaleX, scaleY, 1);
		Matrix.multiplyMM(modelMatrix, 0, vpMatrix, 0, modelMatrix, 0);
		GLES20.glUniformMatrix4fv(matrixHandle, 1, false, modelMatrix, 0);
		
		// 设置纹理坐标数据
		GLES20.glEnableVertexAttribArray(texCoordHandle);
		GLES20.glVertexAttribPointer(texCoordHandle, 2, GLES20.GL_FLOAT, false, 0, texCoordBuffer);
		
		// 绑定纹理
		GLES20.glActiveTexture(GLES20.GL_TEXTURE0);
		GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, textureId);
		GLES20.glUniform1i(textueHandle, 0);
		
		// 绘制
		GLES20.glDrawArrays(GLES20.GL_TRIANGLES, 0, 6);

		// 禁用属性
		GLES20.glDisableVertexAttribArray(positionHandle);
		GLES20.glDisableVertexAttribArray(texCoordHandle);
	}

}
